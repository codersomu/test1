let input = {
    /**
     * Assign Team Members
     */
    co_author: [{
        // group_id: 'Vaccine (In-Vivo)',
        // employee_ids: ["Kiran Ghanta (TTT)","Hélène Goossens"]
        group_id: '',
        employee_ids: []
    }, {
        group_id: '',
        employee_ids: []
    }],
    reviewers: [{
        group_id: '',
        employee_ids: []
    }],
    approvers: [{
        group_id: '',
        employee_ids: []
    }],

    /**
     * Seek Data Source 
     */

    pims_id: '',
    version_id: '',
    start_date: new Date(),
    end_date: '',
    project_name: '',
    study_type: '',
    ethical_protocol_number: '',
    readouts: '',
    animal_species: '',
    immunization_route: '',
    challenge_route: '',
    pathogen: '',
    antigen: '',
    adjuvant: '',
    any_other_keywords: '',

    /**
     * Upload Documents
     */

    uploaded_docs: [],
    cover_page: `
    <p>Efficacy/Challenge Study &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Report Number 20180049</p>
<p><br data-cke-filler="true"></p>
<p><img src="../../../assets/images/report/reports_logo.png" alt="logo" /></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;RSV-Pa</strong></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Non-clinical Efficacy/Challenge study
        report</strong></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp;Study number: 20180049</strong></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Version 01</strong></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Evaluation of potential interference of Pa-RSVPreF3 using the</strong></p>
<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        intranasal challenge mouse model</strong></p>
<p><strong>Author(s):</strong></p>
<p>Marie-Noelle Donner - Scientist</p>
<p><br data-cke-filler="true"></p>
<p><i>signature &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Date : 13/09/19</i></p>
<p><br data-cke-filler="true"></p>
<p><strong>Contributors:</strong></p>
<p>Frédéric Renaud - Statistician</p>
<p>Amal Al Moudan Almanssouri - Requestor</p>
<p><strong>Approver:</strong> &nbsp;</p>
<p>Nadia Ouaked - Maître d expérience</p>
<p><br data-cke-filler="true"></p>
<p>signature &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; Date : 13/09/19</p>
<p><br data-cke-filler="true"></p>
<figure class="table ck-widget ck-widget_with-selection-handle" contenteditable="false">
    <div class="ck ck-widget__selection-handle"><svg class="ck ck-icon" viewBox="0 0 16 16">
            <path
                d="M4 0v1H1v3H0V.5A.5.5 0 0 1 .5 0H4zm8 0h3.5a.5.5 0 0 1 .5.5V4h-1V1h-3V0zM4 16H.5a.5.5 0 0 1-.5-.5V12h1v3h3v1zm8 0v-1h3v-3h1v3.5a.5.5 0 0 1-.5.5H12z">
            </path>
            <path fill-opacity=".256" d="M1 1h14v14H1z"></path>
            <g class="ck-icon__selected-indicator">
                <path d="M7 0h2v1H7V0zM0 7h1v2H0V7zm15 0h1v2h-1V7zm-8 8h2v1H7v-1z"></path>
                <path fill-opacity=".254" d="M1 1h14v14H1z"></path>
            </g>
        </svg></div>
    <table>
        <tbody>
            <tr>
                <td class="ck-editor__editable ck-editor__nested-editable" contenteditable="true">
                    <p>This document is CONFIDENTIAL and the property of the GlaxoSmithKline group of companies.</p>
                    <p>It contains proprietary information and trade secrets. Reproduction, disclosure or use of all or
                        part of the</p>
                    <p>information contained therein is forbidden unless at the express request or with the written
                        consent of</p>
                    <p>GlaxoSmithKline Biologicals &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp; &nbsp; &nbsp;&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
</figure>
    `,

    /**
     * Tabel of content
     */
    table_of_content: `
    <h3>Table of Content</h3>
<ul>
    <li>1. Executive Summary<ul>
            <li>1.1. Objective(s)</li>
            <li>1.2. Study design</li>
            <li>1.3. Results</li>
            <li>1.4. Conclusion</li>
        </ul>
    </li>
    <li>2. Introduction<ul>
            <li>2.1. Background and Scientific Rationale</li>
            <li>2.2. Objectives<ul>
                    <li>&nbsp;2.2.1. Primary objectives</li>
                    <li>&nbsp;2.2.2. Secondary/Exploratory objectives</li>
                </ul>
            </li>
            <li>&nbsp;2.3. Study design<ul>
                    <li>&nbsp;2.3.1. Related studies</li>
                    <li>&nbsp;2.3.2. Overview of the study design</li>
                    <li>&nbsp;2.3.3. Sample size justification</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>&nbsp;3. Materials and Methods<ul>
            <li>&nbsp;3.1. Investigational products</li>
            <li>&nbsp;3.2. Study models<ul>
                    <li>&nbsp;3.2.1. Ethical statement</li>
                    <li>&nbsp;3.2.2. Animal model</li>
                    <li>&nbsp;3.2.3. Housing and husbandry</li>
                    <li>&nbsp;3.2.4. Observations of clinical signs after vaccine administration</li>
                </ul>
            </li>
            <li>&nbsp;3.3. Immunological read-outs<ul>
                    <li>&nbsp;3.3.1. XXXXXX&nbsp;</li>
                    <li>3.3.2. XXXXX&nbsp;</li>
                    <li>3.3.3. XXXX&nbsp;</li>
                    <li>3.3.4. XXXX&nbsp;</li>
                </ul>
            </li>
            <li>3.4. Statistical methods</li>
        </ul>
    </li>
    <li>&nbsp;4. RESULTS&nbsp;</li>
</ul>
<p>In vitro activity of P276-00 on HNSCC cells P276-00 caused G1 arrest in FaDu cells P276-00 targeted CCND1/pRB
    mediated E2F1 pathway causing G1 arrest in FaDu cells P276-00 induced apoptosis through phosphorylation of P53 in
    FaDu cells P276-00 inhibited growth signaling proteins and cytokines in FaDu cells 5. DISCUSSION AND CONCLUSIONS 6.
    REFERENCES (IF APPLICABLE) 7. ANNEXES 7.1. Link to LabNote book or raw data if applicable 7.2. Statistical analyses
    results 7.3. Clinical observations 8. HISTORY OF CHANGES</p>
<h3>Table of Figures and Tables</h3>
<p>Figure 1:&nbsp;</p>
<p>In vitro efficacy of P276-00 caused by G1 arrest in HNSCC cells (a) Anti-proliferative effect of P276-00 on HNSCC
    cells using CCK-8 assay</p>
<p>Figure 2:</p>
<p>P276-00 targeting CCND1/pRB mediated E2F1 pathway and causing G1 arrest in FaDu cells&nbsp;</p>
<p>Figure 3:&nbsp;</p>
<p>Cytotoxic nature of P276-00 is due to phosphorylation of P53 in FaDu cells&nbsp;</p>
<p>Figure 4:</p>
<p>P276-00 inhibit growth signaling proteins and cytokine in FaDu cells.&nbsp;</p>
<p>Figure 5:&nbsp;</p>
<p>Effects of P276-00 on FaDu xenograft.</p>
<p>Figure 6:&nbsp;</p>
<p>Effects of P276-00 on CCND1/pRB mediated E2F1 pathway in FaDu xenograft model</p>
    `,
    /**
     * Executive Summary
     */
    executive_summary: `<h3>1. Executive Summary </h3>
    <p>Tumors of the head and neck present aggressive pathological behavior in patients due to high expression of
        CDK/CCND1 proteins. P276-00, a novel CDK inhibitor currently being tested in clinic, inhibits growth of
        several cancers in vitro and in vivo. The pre clinical activity of P276-00 in head and neck cancer and its
        potential mechanisms of action at molecular level are the focus of the current studies.
    </p>
    <p>We have investigated the anti-cancer activity of P276-00 in head and neck tumors in vitro and in vivo.
        Candidate gene expression profiling and cell based proteomic approaches were taken to understand the
        pathways affected by P276-00 treatment.
    </p>
    <p>It was observed that P276-00 is cytotoxic across various HNSCC cell lines with an IC50 ranging from
        1.0-1.5 μmoles/L and culminated in significant cell-cycle arrest in G1/S phase followed by apoptosis.
        P276-00
        treatment suppressed cell proliferation through inhibition of CCND1 expression, reduced phosphorylation of
        retinoblastoma protein and abrogative transcription of E2F1 gene targets. Further, we observed that
        apoptosis
        was mediated through P53 activation leading to higher BAX/BCL-2 ratio and cleaved caspase-3 levels. It was
        also
        seen that P276-00 treatment reduced expression of tumor micro-environment proteins such as IL-6, secreted
        EGFR
        and HSPA8. Finally, P276-00 treatment resulted in significant tumor growth inhibition in xenograft tumor
        models
        via lowered proliferative activity of E2F1 and aggravated P53 mediated apoptosis.
    </p>
    <p>In summary, we have observed that P276-00 inhibits cyclin-D/CDK4/P16/pRB/E2F axis and induces apoptosis by
        increased P53 phosphorylation in HNSCC cells. These results suggest a novel indication for P276-00 in head
        and neck cancer with a potential role for IL-6 and HSPA8 as candidate serum biomarkers.
    </p>`,
    introduction: `    
    <h2>2 Introduction</h2>
    <h3>2.1 Introduction</h3>
    <h4>2.1.1 Introduction</h4>
    <figure class="image ck-widget ck-widget_selected" contenteditable="false"><img src="https://picsum.photos/id/237/200/200">
        <figcaption>Fig-1:Caption -2</figcaption>
    </figure>
    <figure class="image ck-widget ck-widget_selected" contenteditable="false"><img src="https://picsum.photos/id/237/200/200">
        <figcaption>Fig-1a:Caption -2</figcaption>
    </figure>
    <p>Head and neck squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to
        cancer worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral
        cavity, oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC
        include surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions.
        Aberrant expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis Head and
        neck squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer
        worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity,
        oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC include
        surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions. Aberrant
        expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis Head and neck
        squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer
        worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity,
        oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC include
        surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions. Aberrant
        expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis d neck squamous
        cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer worldwide. Head
        and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity, oropharynx, larynx
        and hypopharynx of which 90% are HNSCC [1].
    </p>
    `,
    objective: `
      <h3>2.2 Objective</h3>
      <p>We have investigated the anti-cancer activity of P276-00 in head and neck tumors in vitro and in vivo.
          Candidate gene expression profiling and cell based proteomic approaches were taken to understand the
          pathways affected by P276-00 treatment
      </p>
    `,
    study_design: `
      <h3>2.3 Study Design</h3>      
      <p>P276-00 is a flavone with cyclin-dependent kinase inhibitor activity and arrests the cells in G1/S phase
          transition [15,16]. Kinase assay profiling studies have shown that P276-00 selectively inhibits CDK4-CCND1
          complex as compared to CDK2-CCNE1 with a 40-fold specificity. P276-00 is also observed to inhibit CDK9-CCNT1
          mediated RNA polymerase II-dependent transcription [17]. In the current study, we have investigated the
          activity of P276-00 in HNSCC and explored the potential mechanism of action of anti-cancer activity in
          multiple HNSCC cancer cells using in vitro and in vivo models.
      </p>
    `,
    materials_methods: `
    
    <h3> 3. Materials & Methods</h3>
        <h4>Antibodies</h4>
        <p>Following primary antibodies were used for various analyses: CCND1, CCNE1, Phospho-RBSer780 (pRB) and E2F1
        (Santa Cruz biotechnology); PCNA (Chemicon); KI67(BD Pharmigen); cleaved-Caspase-3, phospho-P53Ser392 and P16
        (Epitomics); β-Actin antibody (Sigma).</p>
        <h4>Cell lines and culture conditions</h4>
        <p>Human squamous cell carcinoma cell lines- FaDu, Detroit-562 and SCC-25 were obtained from the American Type
            Culture Collection (Manassas, VA). FaDu and Detroit-562 cells were grown in EMEM medium and SCC-25 cells
            were grown in 1:1 mixture of DMEM and Ham’s F12 medium. Both the mediums were supplemented with 10% FBS
            (Hyclone) and 100 U/ml penicillin (Sigma).
        </p>
        <h4>Tumor xenograft model</h4>
        <p>All animal experiments were handled in accordance with the guidelines of “Committee for the Purpose of
            Control and Supervision of Experiments on Animals” which was accredited by the Institutional Animal Ethics
            Committee of Piramal Healthcare. FaDu cells were harvested and re-suspended in saline at 10 million
            cells/0.2 mL volume and injected to severe combined immunodeficient (SCID) mice on right flank. Animals were
            randomized when tumor size attained a diameter of ~5 mm into control and treatment group. Treatment group
            received 50 mg/kg P276-00 solution in water by intraperitoneal route for 18 days. Tumor diameters were
            measured every alternate day and tumor growth inhibition (GI) was calculated as previously reported [15,16].
        </p>
        <h4>Cell viability assay</h4>
        <p> The cytotoxicity of P276-00 was determined using the cell counting kit-8 (CCK8) as per the manufacturer’s
            instructions (Dojindo, Gaithersburg, MD, USA). The change in color due to assay was measured at 450 nM using
            a Tecan sapphire multi-fluorescence microplate absorbance reader (Tecan, Germany).
        </p>
        <h4>Cell cycle analysis</h4>
        <p> Treated and untreated control cells were fixed in 70% ethanol and stained with Propidium iodide (50 mg/ml)
            and RNase A (1 mg/ml). DNA content was measured by flow cytometer (FACS Calibur Becton Dickinson, San Jose,
            CA). Cells with DNA content between 2 N and 4 N were designated as being in G1, S, and G2-M phases of the
            cell cycle. Cells exhibiting < 2 N DNA content were designated as sub-G0 cells. The number of cells in each
                cell cycle compartment was expressed as a percentage of the total number of cells. </p>
                <h4>mRNA expression assay</h4>
                <p> Extraction of total RNA was carried out using chloroform-ethanol precipitation method. Cells/tissues
                    were lysed using Trizol Reagent (Invitrogen Corporation, Carlsbad, USA). The RNA was purified using
                    RNeasy Mini kit (Qiagen GmbH, Hilden, Germany). For cDNA conversion, 2 μg of total RNA was reverse
                    transcribed to cDNA using 200 units of Superscript III (Invitrogen Corporation, Carlsbad, CA, USA)
                    as per manufacturer’s protocol. Further real-time PCR was performed in 96-well plates using
                    Realplex™ Mastercycler System (Eppendorf, Germany) and the fluorescent SYBR green dye (Quantifast™
                    SYBR Green PCR Kit., Qiagen GmbH, Hilden, Germany). Data were analyzed using the Realplex™ software
                    (version 1.5). The relative expression of genes was calculated with the relative Ct method [18]
                    using GAPDH as housekeeping gene for normalization of data.
                </p>
                <h4>Western blotting</h4>
                <p> FaDu cells were lysed with cell lysis buffer (cell signaling), resolved on a 10% SDS-PAGE gels and
                    transferred to nitrocellulose membrane (Sigma-Aldrich, MO, USA). Membrane was blocked with 5% non
                    fat milk (Santa Cruz Biotechnology, city, CA, USA) and treated with the primary antibody overnight
                    at 4°C followed by HRP conjugated secondary antibody. After incubation, bound antibodies were
                    detected with enhanced chemifluorescence (ECF) substrate (Sigma-Aldrich, MO, USA) and analyzed by
                    Kodak Image station 4000MM (Kodak, Roches, CA).
                </p>
                <h4>Cell based automated fluorescence imaging</h4>
                <p> FaDu cells were grown in 96-well plates and treated with different concentrations of P276-00 for 24
                    hours. Treated/untreated cells were fixed with 3.7% formaldehyde (Merck Biosciences, Darmstadt,
                    Germany) for 20 min. and permeabilized using chilled permeabilization buffer (0.15% Triton X-100;
                    Thermo Scientific, Waltham, MA) for 1.5 min. Subsequently the cells were blocked with DPBS
                    containing 5% FBS and 5% goat serum (Vector Laboratories Inc., Burlingame, CA) for 1 hour at room
                    temperature. Thereafter cells were incubated with primary antibody at 4°C overnight. This was
                    followed by staining with DyLight™ 549-conjugated goat antibody (Thermo Scientific; Waltham, MA) and
                    nuclear staining with Hoechst 33342 (AnaSpec Inc; Fermont, CA). The plates were scanned to acquire
                    images on the ArrayScan® HCS reader (Thermo Scientific.). All the data points were analyzed using
                    compartmental analysis bio-algorithm (Cellomics Inc. Pittsburgh PA). The results were expressed as
                    percentage (%) deregulation as compared to control (vehicle) cells for each protein. The 50%
                    effective concentrations (EC50) were calculated using nonlinear regression method with GraphPad
                    software (Prism 5).
                </p>
                <h4>Elisa</h4>
                <p> Supernatants were collected from treated and untreated cells and assayed for HSPA8 and IL-6 by ELISA
                    (Enzyme-Linked Immunosorbent Assay) using HSPA8 ELISA kit (USCN Life Sciences Inc, Wuhan, China) and
                    IL-6 ELISA kit (OptiEIA ELISA sets; BD Biosciences) as per the manufacturer’s protocol. The 50%
                    inhibitory concentration (IC50) values were calculated by nonlinear regression method using GraphPad
                    software (Prism5).
                </p>
                <h4>Immunohistochemical analysis of tumor xenografts</h4>
                <p> The formalin fixed paraffin embedded sections of xenograft tumor tissue from control and treated
                    groups were stained by immunohistochemistry for specific proteins. The slides were deparaffinized
                    followed by antigen retrieval by incubating the slides in citrate based antigen unmasking solution
                    (pH 6.0) (Vector Labs, CA, USA) for 30 minutes. Slides were then blocked for two hours with 1X
                    blocking buffer (containing 2% FBS, 2% FCS, 5% goat serum, 5% donkey serum, 1%BSA and 0.1% triton-x)
                    followed by incubation with primary antibody overnight at 4°C. Slides were incubated with secondary
                    antibody conjugated with DyLight 549 fluorescent dye for 60 minutes at 37°C and mounted with
                    Vectastain® Elite ABC reagent. All tumor tissues without primary antibody were used as negative
                    control throughout the study. Images were captured with Nikon E600 microscope equipped with a
                    DXM1200F digital camera (Nikon USA). Pixel intensities were measured using ImageJ software
                    (http://rsb.info.nih.gov/ij/).
                </p>
    `,
    results: `
    <h3>4. Results</h3>
    <h4>In vitro activity of P276-00 on HNSCC cells</h4>
    <p>Anti-cancer properties of P276-00 were tested across multiple HNSCC cell lines (FaDu, Detroits-562, SCC-25) by measuring dehydrogenase based tetrazolium salt reduction produced by viable cells (Figure 1a). The results showed significant inhibition of cell viability for all three cell lines with IC50 value ranging from 0.8 to 1.7 μM depending on specific cell lines.
    </p>
    <img src='../../../assets/images/report/result_fig_1.jpg' />

    `,
    discussion_conclusions: `
    <h3>5 - Discussion & Conclusions</h3>
        <p>P276-00, a novel CDK inhibitor, is currently under clinical investigation for HNSCC
        (http://clinicaltrials.gov/show/NCT00824343). In the present study, we have demonstrated anti-cancer properties
        of P276-00 against HNSCC using in vitro and in vivo tumor models. We observed significant inhibition of E2F1 and
        its targets via reduced RB phosphorylation by P276-00. We also demonstrated that P276-00 promoted apoptosis by
        phosphorylation of P53 resulting in increased BAX/BCL2 ratio and elevated levels of cleaved caspase-3.
        Furthermore, P276-00 inhibited expression of soluble proteins such as IL-6, EGFR and HSPA8 that promote tumor
        microenvironment.</p>
        <p> 
        The anti-cancer properties of flavones such as flavopiridol through CDK inhibition have been established in head
        and neck cancer [19]. P276-00, a flavone with a specific CDK1/4/9 inhibition activity, has been studied for
        anticancer effects in several other cancers but not HNSCC [15,16]. In the current study, we demonstrated the
        anti-cancer properties of P276-00 in HNSCC. Cell lines over expressing CCND1 viz., FaDu, Detroits-562 and SCC-25
        were very sensitive to P276-00 as observed in the cytotoxicity assay, which is similar to previously reported
        evidence in other cell lines [15,16]. As FaDu cells have highest CCND1 expression and accordingly showed highest
        in vitro sensitivity to P276-00, we employed these cells for subsequent investigations in vitro and in vivo.
        We observed that P276-00 resulted in 48% tumor growth inhibition (TGI) by day 18 post drug administration with
        minimal toxicity to animals as observed by the animal body weight loss (less than 10% of total body weight loss
        -data not shown) in the FaDu xenograft model. This TGI value is comparable to the reported data for anti-tumor
        activity (40% optimal TGI) [20]. Thus our in vivo study with FaDu xenograft model establishes the therapeutic
        validity of P276-00.</p>
        <p> 
        CDK inhibitors interfere with the cell cycle progression through inhibition of cell proliferation and induction
        of apoptosis. We have evaluated the status of P276–00 treated FaDu cells by flow cytometry and observed that
        P276-00 blocks cell cycle progression by G1 arrest. Our findings are in accordance with a prior report by
        Carlson and colleagues, who demonstrated that flavopiridol causes cell cytotoxicity by G1-S phase arrest in
        MDA-MB-468 breast carcinoma cells [21]. RB protein, a tumor suppressor that blocks E2F transcription factor,
        regulates transcription of E2F-responsive genes involved in cell cycle progression from G1 to S phase. It is
        well established that CDK4/CCND1 complex phosphorylates RB and thus releases E2F to initiate transcription [6-8]
        of genes such as cMYC, CCNE1, PCNA, KI67, RRM2 and E2F1 [22-26] which are crucial for the entry of cells into
        the S phase. On the contrary, P16 inhibits phosphorylation of RB protein and attenuates E2F1 activity. Loss of
        P16 expression has been observed in 55% of HNSCC tumors [4]. We observed a significant inhibition of CCND1
        expression and RB phosphorylation followed by reduced transcription of E2F1 targeted genes in presence of
        P276-00 under both in vitro and in vivo conditions. The on-off dose-responses for CCND1 and E2F1 have important
        clinical implications suggesting that lower concentrations of P276-00 can be clinically used without noticeable
        loss in efficacy. These observations suggest that P276-00 mediates its anti-proliferative activity via
        inhibition of CCND1/pRB/E2F1 pathway leading to G1-S phase arrest. On the other hand, G2/M check point markers
        CCNB1, PLK1 and BUB1 [25,27] showed marginal inhibition by P276-00, which further compliments the moderate
        arrest of cells in G2/M phase in FACS analysis. Human ARF/INK4a locus encodes two cell cycle inhibitors,
        P16INK4a (P16) and P14ARF (P14), which are directly modulated by E2F1 [28,29]. P276-00 induced the expression of
        P16 and P14 in a time-dependent manner at lower dose levels. Low levels of P16 and P14 transcript observed with
        the higher concentration of P276-00 could be due to overall E2F1 mediated transcriptional repression by P276-00.
        The temporal relationship among abrogated levels of phosphorylated RB and E2F1 targets explains inhibition of G1
        phase of the cell cycle via CCND1/pRB/E2F1 pathway.</p>
        <p> 
        Prolonged cell cycle arrest causes apoptosis [30]. FaDu cells are known to express mutant P53 with a point
        mutation on codon 248 [31]. Despite this point mutation, phosphorylation of P53 at Ser392 results in
        transactivation of P53 and oncogenic function of P53 mutant [32]. Activated (phosphorylated) P53 trans-represses
        anti-apoptotic BCL-2 [33,34] and over expresses pro-apoptotic BAX [33], which triggers the caspase cascade.
        Consistently, P276-00 treatment in FaDu cells showed increased P53 phosphorylation at Ser392 and cleaved CASP-3
        expression along with reduced BCL2 to BAX ratio, which was associated with enhanced apoptosis (measured by
        FACS). The decrease in proapoptotic BAX mRNA expression at higher concentrations of P276-00 could be due to
        overall CDK9/CyclinT1-mediated repression of basal transcriptional machinery by P276-00 [17]. However, this
        needs additional validation.</p>
        <p> 
        Growth signaling proteins and cytokines, that promote cell growth, inflammation, and angiogenesis, play an
        important role in tumor microenvironment enhancing tumor proliferation, invasion, and metastasis [35]. Molecular
        pathogenesis of HNSCC is also driven by similar alterations in growth and immune signalling [12,36]. HNSCC
        tumors get nourished due to its microenvironment and are well supplied with soluble epidermal growth factor
        receptor (EGFR) and cytokine (IL-6), which play a critical role in tumor aggressiveness and their response to
        various therapies [12,36]. Higher levels of IL-6 and EGFR in HNSCC cancer patients’ serum are found to be
        associated with a higher second primary cancer (SPC) specific mortality and hence established as serum
        biomarkers for HNSCC [14]. Dose-dependent inhibition of EGFR and IL-6 by P276-00 supports its sensitivity
        against growth promotion of HNSCC. Additionally, HSPA8 is a member of the heat-shock protein 70 families and
        known to promote cancer cell growth [13]. HSPA8 is important for stability of CCND1 mRNA and also helps to form
        a complex with CDK4 [37]. Interestingly, we have observed significant inhibition of HSPA8 by P276-00 at mRNA and
        protein levels in dose-dependent manner. Based on these observations, we propose that the secretary levels of
        IL-6 and HSPA8 could be the potential efficacy biomarker for P276-00 treatment in the clinic.
        We conclude that P276-00 has potent anti-proliferative and anti-tumor effects in HNSCC in vitro and in vivo. The
        findings from our study provide mechanistic insights into the anti-cancer activity of P276-00 and its effect on
        CCND1/CDK4/P16/pRB/E2F signaling cascade in FaDu cells. Being the key mediators of cancer survival,
        pharmacological inhibition of E2F1 targets is an attractive option for therapeutic intervention against cancer.
        Therefore, P276-00 can serve as a promising candidate in HNSCC therapy, particularly for those lesions that over
        expresses CCND1 and are insensitive to conventional therapy.
        </p>

    `,
    references: `
    <h3>6 References</h3>
1.	Curado MP, Hashibe M. Recent changes in the epidemiology of head and neck cancer. Curr Opin Oncol. 2009;21(3):194–200. doi: 10.1097/CCO.0b013e32832a68ca. [PubMed] [CrossRef] [Google Scholar]
<br /><br />2.	Perez-Ordonez B, Beauchemin M, Jordan RC. Molecular biology of squamous cell carcinoma of the head and neck. J Clin Pathol. 2006;59(5):445–453. doi: 10.1136/jcp.2003.007641. [PMC free article][PubMed] [CrossRef] [Google Scholar]
<br /><br />3.	Resnitzky D, Reed SI. Different roles for cyclins D1 and E in regulation of the G1-to-S transition. Mol Cell Biol. 1995;15(7):3463–3469. [PMC free article] [PubMed] [Google Scholar]
<br /><br />4.	Bova RJ, Quinn DI, Nankervis JS, Cole IE, Sheridan BF, Jensen MJ, Morgan GJ, Hughes CJ, Sutherland RL. Cyclin D1 and p16INK4A expression predict reduced survival in carcinoma of the anterior tongue. Clin Cancer Res Off j Am Assoc Cancer Res. 1999;5(10):2810–2819. [PubMed] [Google Scholar]
<br /><br />5.	Kalish LH, Kwong RA, Cole IE, Gallagher RM, Sutherland RL, Musgrove EA. Deregulated cyclin D1 expression is associated with decreased efficacy of the selective epidermal growth factor receptor tyrosine kinase inhibitor gefitinib in head and neck squamous cell carcinoma cell lines. Clin cancer Res Off J Am Assoc Cancer Res. 2004;10(22):7764–7774. doi: 10.1158/1078-0432.CCR-04-0012.[PubMed] [CrossRef] [Google Scholar]
<br /><br />6.	Trimarchi JM, Lees JA. Sibling rivalry in the E2F family. Nat Rev Mol Cell Biol. 2002;3(1):11–20.[PubMed] [Google Scholar]
<br /><br />7.	Harbour JW, Dean DC. The Rb/E2F pathway: expanding roles and emerging paradigms. Genes Dev. 2000;14(19):2393–2409. doi: 10.1101/gad.813200. [PubMed] [CrossRef] [Google Scholar]
<br /><br />8.	Dyson N. The regulation of E2F by pRB-family proteins. Genes Dev. 1998;12(15):2245–2262. doi: 10.1101/gad.12.15.2245. [PubMed] [CrossRef] [Google Scholar]
<br /><br />9.	Brennan JA, Boyle JO, Koch WM, Goodman SN, Hruban RH, Eby YJ, Couch MJ, Forastiere AA, Sidransky D. Association between cigarette smoking and mutation of the p53 gene in squamous-cell carcinoma of the head and neck. N Engl J Med. 1995;332(11):712–717. doi: 10.1056/NEJM199503163321104. [PubMed] [CrossRef] [Google Scholar]
<br /><br />10.	Koch WM, Brennan JA, Zahurak M, Goodman SN, Westra WH, Schwab D, Yoo GH, Lee DJ, Forastiere AA, Sidransky D. p53 mutation and locoregional treatment failure in head and neck squamous cell carcinoma. J Nat Cancer Institute. 1996;88(21):1580–1586. doi: 10.1093/jnci/88.21.1580. [PubMed] [CrossRef] [Google Scholar]
<br /><br />11.	Shin DM, Mao L, Papadimitrakopoulou VM, Clayman G, El-Naggar A, Shin HJ, Lee JJ, Lee JS, Gillenwater A, Myers J. Biochemopreventive therapy for patients with premalignant lesions of the head and neck and p53 gene expression. J Nat Cancer Institute. 2000;92(1):69–73. doi: 10.1093/jnci/92.1.69. [PubMed] [CrossRef] [Google Scholar]
<br /><br />12.	Klein JD, Grandis JR. The molecular pathogenesis of head and neck cancer. Cancer biol therapy. 2010;9(1):1–7. [PMC free article] [PubMed] [Google Scholar]
<br /><br />13.	Rohde M, Daugaard M, Jensen MH, Helin K, Nylandsted J, Jaattela M. Members of the heat-shock protein 70 family promote cancer cell growth by distinct mechanisms. Genes Dev. 2005;19(5):570–582. doi: 10.1101/gad.305405. [PMC free article] [PubMed] [CrossRef] [Google Scholar]
<br /><br />14.	Meyer F, Samson E, Douville P, Duchesne T, Liu G, Bairati I. Serum prognostic markers in head and neck cancer. Clin cancer Res off J Am Assoc Cancer Res. 2010;16(3):1008–1015. doi: 10.1158/1078-0432.CCR-09-2014. [PubMed] [CrossRef] [Google Scholar]
<br /><br />15.	Joshi KS, Rathos MJ, Mahajan P, Wagh V, Shenoy S, Bhatia D, Chile S, Sivakumar M, Maier A, Fiebig HH. P276-00, a novel cyclin-dependent inhibitor induces G1-G2 arrest, shows antitumor activity on cisplatin-resistant cells and significant in vivo efficacy in tumor models. Mol Cancer Ther. 2007;6(3):926–934. doi: 10.1158/1535-7163.MCT-06-0614. [PubMed] [CrossRef] [Google Scholar]
<br /><br />16.	Joshi KS, Rathos MJ, Joshi RD, Sivakumar M, Mascarenhas M, Kamble S, Lal B, Sharma S. In vitroantitumor properties of a novel cyclin-dependent kinase inhibitor, P276-00. Mol Cancer Ther. 2007;6(3):918–925. doi: 10.1158/1535-7163.MCT-06-0613. [PubMed] [CrossRef] [Google Scholar]
<br /><br />17.	Manohar SM, Rathos MJ, Sonawane V, Rao SV, Joshi KS. Cyclin-dependent kinase inhibitor, P276-00 induces apoptosis in multiple myeloma cells by inhibition of Cdk9-T1 and RNA polymerase II-dependent transcription. Leuk Res. 2011;35(6):821–830. doi: 10.1016/j.leukres.2010.12.010.[PubMed] [CrossRef] [Google Scholar]
<br /><br />18.	Livak KJ, Schmittgen TD. Analysis of relative gene expression data using real-time quantitative PCR and the 2(−delta delta C(T)) method. Methods. 2001;25(4):402–408. doi: 10.1006/meth.2001.1262. [PubMed] [CrossRef] [Google Scholar]
<br /><br />19.	Patel V, Senderowicz AM, Pinto D Jr, Igishi T, Raffeld M, Quintanilla-Martinez L, Ensley JF, Sausville EA, Gutkind JS. Flavopiridol, a novel cyclin-dependent kinase inhibitor, suppresses the growth of head and neck squamous cell carcinomas by inducing apoptosis. J Clin Investig. 1998;102(9):1674–1681. doi: 10.1172/JCI3661. [PMC free article] [PubMed] [CrossRef] [Google Scholar]
<br /><br />20.	Plowman J, Dykes DJ, Hollingshead M, Simpson-Herren L, Alley MC. In: Anticancer drug development guide: preclinical screening, clinical trials, and approval. Teicher BA, editor. Totowa, NJ: Humana Press Inc; 1997. Human tumor xenograft models in NCI drug development; pp. 101–130. [Google Scholar]
<br /><br />21.	Carlson BA, Dubay MM, Sausville EA, Brizuela L, Worland PJ. Flavopiridol induces G1 arrest with inhibition of cyclin-dependent kinase (CDK) 2 and CDK4 in human breast carcinoma cells. Cancer Res. 1996;56(13):2973–2978. [PubMed] [Google Scholar]
<br /><br />22.	DeGregori J, Kowalik T, Nevins JR. Cellular targets for activation by the E2F1 transcription factor include DNA synthesis- and G1/S-regulatory genes. Mol Cell Biol. 1995;15(8):4215–4224.[PMC free article] [PubMed] [Google Scholar]
<br /><br />23.	Johnson DG, Schwarz JK, Cress WD, Nevins JR. Expression of transcription factor E2F1 induces quiescent cells to enter S phase. Nature. 1993;365(6444):349–352. doi: 10.1038/365349a0.[PubMed] [CrossRef] [Google Scholar]
<br /><br />24.	Li YY, Wang L, Lu CD. An E2F site in the 5’-promoter region contributes to serum-dependent up-regulation of the human proliferating cell nuclear antigen gene. FEBS Lett. 2003;544(1–3):112–118.[PubMed] [Google Scholar]
<br /><br />25.	Whitfield ML, George LK, Grant GD, Perou CM. Common markers of proliferation. Nat Rev Cancer. 2006;6(2):99–106. doi: 10.1038/nrc1802. [PubMed] [CrossRef] [Google Scholar]
<br /><br />26.	Zhang YW, Jones TL, Martin SE, Caplen NJ, Pommier Y. Implication of checkpoint kinase-dependent up-regulation of ribonucleotide reductase R2 in DNA damage response. J Biol Chem. 2009;284(27):18085–18095. doi: 10.1074/jbc.M109.003020. [PMC free article] [PubMed] [CrossRef] [Google Scholar]
<br /><br />27.	Ren B, Cam H, Takahashi Y, Volkert T, Terragni J, Young RA, Dynlacht BD. E2F integrates cell cycle progression with DNA repair, replication, and G(2)/M checkpoints. Genes Dev. 2002;16(2):245–256. doi: 10.1101/gad.949802. [PMC free article] [PubMed] [CrossRef] [Google Scholar]
<br /><br />28.	Sherr CJ, Roberts JM. CDK inhibitors: positive and negative regulators of G1-phase progression. Genes Dev. 1999;13(12):1501–1512. doi: 10.1101/gad.13.12.1501. [PubMed] [CrossRef] [Google Scholar]
<br /><br />29.	Parisi T, Pollice A, Di Cristofano A, Calabro V, La Mantia G. Transcriptional regulation of the human tumor suppressor p14(ARF) by E2F1, E2F2, E2F3, and Sp1-like factors. Biochem Biophys Res Commun. 2002;291(5):1138–1145. doi: 10.1006/bbrc.2002.6591. [PubMed] [CrossRef] [Google Scholar]
<br /><br />30.	Vermeulen K, Berneman ZN, Van Bockstaele DR. Cell cycle and apoptosis. Cell proliferation. 2003;36(3):165–175. doi: 10.1046/j.1365-2184.2003.00267.x. [PMC free article] [PubMed] [CrossRef] [Google Scholar]
<br /><br />31.	Kim MS, Li SL, Bertolami CN, Cherrick HM, Park NH. State of p53, Rb and DCC tumor suppressor genes in human oral cancer cell lines. Anticancer Res. 1993;13(5A):1405–1413. [PubMed] [Google Scholar]
<br /><br />32.	Yap DB, Hsieh JK, Zhong S, Heath V, Gusterson B, Crook T, Lu X. Ser392 phosphorylation regulates the oncogenic function of mutant p53. Cancer Res. 2004;64(14):4749–4754. doi: 10.1158/0008-5472.CAN-1305-2. [PubMed] [CrossRef] [Google Scholar]
<br /><br />33.	Miyashita T, Reed JC. Tumor suppressor p53 is a direct transcriptional activator of the human bax gene. Cell. 1995;80(2):293–299. doi: 10.1016/0092-8674(95)90412-3. [PubMed] [CrossRef] [Google Scholar]
<br /><br />34.	Miyashita T, Harigai M, Hanada M, Reed JC. Identification of a p53-dependent negative response element in the bcl-2 gene. Cancer Res. 1994;54(12):3131–3135. [PubMed] [Google Scholar]
<br /><br />35.	Elenbaas B, Weinberg RA. Heterotypic signaling between epithelial tumor cells and fibroblasts in carcinoma formation. Experiment Cell Res. 2001;264(1):169–184. doi: 10.1006/excr.2000.5133.[PubMed] [CrossRef] [Google Scholar]
<br /><br />36.	Pries R, Wollenberg B. Cytokines in head and neck cancer. Cytokine growth factor rev. 2006;17(3):141–146. doi: 10.1016/j.cytogfr.2006.02.001. [PubMed] [CrossRef] [Google Scholar]
<br /><br />37.	Diehl JA, Yang W, Rimerman RA, Xiao H, Emili A. Hsc70 regulates accumulation of cyclin D1 and cyclin D1-dependent protein kinase. Mol Cell Biol. 2003;23(5):1764–1774. doi: 10.1128/MCB.23.5.1764-1774.2003. [PMC free article] [PubMed] [CrossRef] [Google Scholar]

    `,
    annexes: `
    <h3>7 Annexes</h3>
    <p>Head and neck squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to
        cancer worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral
        cavity, oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC
        include surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions.
        Aberrant expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis Head and
        neck squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer
        worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity,
        oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC include
        surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions. Aberrant
        expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis Head and neck
        squamous cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer
        worldwide. Head and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity,
        oropharynx, larynx and hypopharynx of which 90% are HNSCC [1]. Current treatment options for HNSCC include
        surgery, γ-irradiation, and chemotherapy depending on the site, size and the stage of lesions. Aberrant
        expression of P14, P16, P53, CCND1, RAS, EGFR, and MYC is known to initiate tumorigenesis d neck squamous
        cell carcinoma (HNSCC) is the 8th most common cause of morbidity and mortality due to cancer worldwide. Head
        and neck cancer refers to carcinoma arising in the mucosal surfaces of the oral cavity, oropharynx, larynx
        and hypopharynx of which 90% are HNSCC [1].
    </p>
    `,
    history_of_changes: `
    8. <h3>History of changes</h3>
    `,
    compile_report: `
    9. <h3>Compile report</h3>
    `,
    report_status: {
        '': 0,
        '': 0,
        '': 0,
        '': 0,
        'cover_page': 0,
        'table_of_content': 0,
        'executive_summary': 0,
        'introduction': 0,
        'objective': 0,
        'study_design': 0,
        'materials_methods': 0,
        'results': 0,
        'discussion_conclusions': 0,
        'references': 0,
        'annexes': 0,
        'history_of_changes': 0,
        'compile_report': 0
    }
}

export default input;