import { Component, OnInit, ViewChild, Input, Inject } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NewreportService } from "../../_services/newreport.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RobocommentService } from "../../_services/robocomment.service";
import { Subscription } from 'rxjs';
import { JsonPipe } from '@angular/common';



@Component({
  selector: 'app-cskeditor-panel',
  templateUrl: './cskeditor-panel.component.html',
  // templateUrl: './popoup-seek-data-source.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class CskeditorPanelComponent implements OnInit {

  public Editor = ClassicEditor;
  public selection = 0;
  public currentPosition: any = 0;
  public currentFunction: any = {};
  public content: any = '';
  public showButton: boolean = true;
  public isEditorDisabled = false;

  private subscription: Subscription;

  public seekDataAbrv = "";

  public mlImages = [
    {
      type : 'image',
      url: 'https://picsum.photos/200/200',
      caption: 'Caption -1'
    },
    {
      type : 'image',
      url: 'https://picsum.photos/id/237/200/200',
      caption: 'Caption -2'
    },
    {
      type : 'image',
      url: 'https://picsum.photos/seed/picsum/200/200',
      caption: 'Caption -3'
    },
    {
      type : 'image',
      url: 'https://picsum.photos/200/200?grayscale',
      caption: 'Caption -4'
    },
    {
      type : 'image',
      url: 'https://picsum.photos/200/200/?blur=2',
      caption: 'Caption -5'
    },
    {
      type : 'image',
      url: 'https://picsum.photos/id/870/200/200?grayscale&blur=2',
      caption: 'Caption -6'
    }
  ];



  public indexs = [];
  currentStep: number;
  constructor(
    private NewreportService: NewreportService,
    public dialog: MatDialog,
    private roboComment: RobocommentService) {

  }

  @ViewChild('editor') editorComponent: ClassicEditor;
  @Input() currentReport: any;

  openDialog() {
    if (Object.keys(this.currentFunction).length) {
      const dialogRef = this.dialog.open(PopupSeekDataSource, {
        width: '90%',
        data: { seekDataAbrv: 'HTML.K.L' }
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed', result);
        this.seekDataAbrv = result;
        this.insert();
      });
    } else {
      this.roboComment.setComment({
        status: 'error',
        message: '<b>Please</b>,selecte the position to insert seek data!'
      })
    }
  }

  openMLDialog() {

    const dialogRef = this.dialog.open(PopupMLImage, {
      width: '90%',
      data: { images: this.mlImages, selectedImage: '' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (typeof result !== "undefined") {
        this.insertImage(result);
      }
    });
  }

  async insertSubsection() {


    this.editorComponent.editorInstance.fire('click');

    await this.editorComponent.editorInstance.model.change(writer => {

      const image = writer.createElement('image');
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted subsection!'
      })
    });

    const words = this.content.split('<figure class="image"><img></figure>');
    const last_headings = words[0].split('<h');

   
    const curent_heading  = parseInt(last_headings[last_headings.length - 1].substring(0, 1));

    if(isNaN(curent_heading)){
      this.editorComponent.editorInstance.setData(words.join(''));
      this.roboComment.setComment({
        status: 'error',
        message: '<b>Invalid Header</b>!'
      });
      return false;
    }

    const pre =  curent_heading + '>(.*?)</h' + curent_heading + '>';
    var myRe = new RegExp(pre, 'g');
    var heading_content = myRe.exec(last_headings[last_headings.length - 1]);
    const number = heading_content[1].split(' ');
    const heading_number = number[0] + '.1';

    const next_heading =  curent_heading + 1;
    const header = '<h' + next_heading + '>'+heading_number+' [Heading-' + (next_heading - 1) + ']</h' + next_heading + '>';
    this.editorComponent.editorInstance.setData(words.join(header));
  }




  ngOnInit(): void {
    this.indexs = this.NewreportService.tabindexes;

    this.subscription = this.NewreportService.currentStepChange
      .subscribe(step => {
        console.log('step', step);
        this.currentStep = step;
        this.content = this.currentReport[this.indexs[this.currentStep]];
        this.showButton = true;
        if (this.currentReport.report_status[this.indexs[this.currentStep]]) {
          this.showButton = false;
        }
        this.isEditorDisabled = false;

        if (this.currentStep == 5) {
          this.getTableOFContent();
        }
      });

  }

  getTableOFContent() {


    /**
     * If the current step is 7 that is cover page 
    */

    //console.log('this.currentStep', this.currentStep);

    /**  to be moved to service */

    const indexs = ['executive_summary',
      'introduction',
      'objective',
      'study_design',
      'materials_methods',
      'results',
      'discussion_conclusions',
      'references',
      'annexes',
      'history_of_changes',
      'compile_report'];

    let content = [];
    content = indexs.map(index => {

      //console.log('content',  this.currentReport[index]);
      //console.log('index',index)
      const total_headers = this.currentReport[index].split('<h');
      console.log('total_headers', total_headers)
      let html = "";
      let currentList = 0;
      let headers = total_headers.map(data => {
        if (data.trim()) {
          const number = parseInt(data.substring(0, 1));
          const pre = number + '>(.*?)</h' + number + '>';
          var myRe = new RegExp(pre, 'g');
          var myArray = myRe.exec(data);
          if (myArray && myArray[1]) {
            const li = "<li>" + myArray[1] + "</li>";
            console.log('number' + number + 'currentList' + currentList);

            if (currentList < number) {
              html += '<ul>' + li;
            }
            if (currentList > number) {

              html += '</ul>' + li;
            }
            if (number == currentList) {
              html += li;
            }
            currentList = number;
          }
        }
      });

      if (html != '') {
        html += "</ul>";
      }
      return html;
    });
    const n =  "<h2>Table of Content</h2>" + content.join('') + " <p></p><h3>Table of Figures and Tables</h3>";
    console.log(n);
    this.content = n;
    this.isEditorDisabled = true;
  }

  save() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Saved</b> this section Successfully!'
    })
    this.currentReport[this.indexs[this.currentStep]] = this.content;

    this.currentReport.report_status[this.indexs[this.currentStep]] = 0;
  }

  commit() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Committed</b> this section Successfully!'
    })
    this.currentReport.report_status[this.indexs[this.currentStep]] = 1;
    this.showButton = false;
  }

  insert() {
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      writer.insertText(this.seekDataAbrv, this.currentPosition);
      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  insertImage(image) {
    const src = image.url;
    const last_headings = this.content.split('<figure'); // + (this.currentStep - 4) + '.'
    const captionText = 'Fig-' + last_headings.length +':' + image.caption;
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      const image = writer.createElement('image', { src: src });
      const caption = writer.createElement('caption');
      writer.appendText(captionText, caption);
      writer.append(caption, image);
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  getPosition() {

    this.currentPosition = this.editorComponent.editorInstance.model.document.selection.getFirstPosition();
    this.editorComponent.editorInstance.model.change(writer => {
      this.currentFunction = writer;
    });
  }
}



@Component({
  selector: 'popoup-seek-data-source',
  templateUrl: 'popoup-seek-data-source.html',
  styleUrls: ['../seek-data-source/seek-data-source.component.sass']
})
export class PopupSeekDataSource {

  pims_ids: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];

  currentReport: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];
  today = new Date();


  constructor(
    public dialogRef: MatDialogRef<PopupSeekDataSource>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }


  loadData(id = 1) {
    let temp = this.pims_ids[0];
    Object.keys(temp).forEach((value, index) => {
      // this.currentReport[value] = temp[value];
    });
  }

  closePopUp() {
    this.dialogRef.close();
  }

  seek() {

  }

}




@Component({
  selector: 'popoup-mlimages',
  templateUrl: 'popoup-ml-images.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class PopupMLImage {
  selected

  constructor(
    public dialogRef: MatDialogRef<PopupMLImage>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    data.selectedImage = data.images[0];
    // console.log(data.images)
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  closeMlPopup() {
    this.dialogRef.close();
  }

  insertMlImage() {
    console.log('data.selectedImage', this.data.selectedImage);
    this.dialogRef.close();
  }

}
