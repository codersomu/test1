import {AfterViewInit, OnDestroy, Component, OnInit, ViewChild, Input, Inject, Output, EventEmitter, ElementRef } from '@angular/core';
// import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import {CKEditor5} from '@ckeditor/ckeditor5-angular';
import * as ClassicEditorBuild from '../../../../vendor/ckeditor5/build/classic-editor-with-track-changes.js';
import { NewreportService } from "../../_services/newreport.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RobocommentService } from "../../_services/robocomment.service";
import { Subscription } from 'rxjs';
import { JsonPipe } from '@angular/common';
import { getLoadSaveIntegration } from './load-save-integration';
//import * as jsPDF from 'jspdf';
//import * as HtmltoDoc from 'html-docx-js';

@Component({
  selector: 'app-cskeditor-panel',
  templateUrl: './cskeditor-panel.component.html',
  // templateUrl: './popoup-seek-data-source.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class CskeditorPanelComponent implements OnInit,AfterViewInit, OnDestroy {
// @ViewChild('editor') editorComponent: ClassicEditor;
@Output() public ready = new EventEmitter<CKEditor5.Editor>();
@ViewChild('editor') editorComponent: CKEditor5.Editor;

@Input() currentReport: any;

@ViewChild( 'sidebar', { static: true } ) private sidebarContainer?: ElementRef<HTMLDivElement>;


  public Editor = ClassicEditorBuild;
  public selection = 0;
  public currentPosition: any = 0;
  public currentFunction: any = {};
  public content: any = '';
  public showButton: boolean = true;
  public isEditorDisabled = false;
  

  public get editorConfig() {
		return {
			extraPlugins: [
				getLoadSaveIntegration( this.appData )
			],
			sidebar: {
				container: this.sidebar,
			},
			licenseKey: this.licenseKey
		};
	}

  

	private readonly STORAGE_KEY = 'sLxId4TgBkkUxtbA0CqxllN84HZzYgINyL6ePBvakNgpAQyS/tms';
	private licenseKey = 'sLxId4TgBkkUxtbA0CqxllN84HZzYgINyL6ePBvakNgpAQyS/tms';

	// Application data will be available under a global variable `appData`.
	private appData = {
		// The ID of the current user.
		userId: 'user-1',
		// Users data.
		users: [
			{
				id: 'user-1',
				name: 'Joe Doe',
				// Note that the avatar is optional.
				avatar: 'https://randomuser.me/api/portraits/thumb/men/26.jpg'
			},
			{
				id: 'user-2',
				name: 'Ella Harper',
				avatar: 'https://randomuser.me/api/portraits/thumb/women/65.jpg'
			}
		],
		// Suggestion threads data.
		suggestions: [],
		// Comment threads data.
		commentThreads: []
  };

  // Note that Angular refs can be used once the view is initialized so we need to create
	// this container and use in the above editor configuration to work around this problem.
	private sidebar = document.createElement( 'div' );

	private boundRefreshDisplayMode = this.refreshDisplayMode.bind( this );
	private boundCheckPendingActions = this.checkPendingActions.bind( this );
  

  private subscription: Subscription;

  public seekDataAbrv = "";

  public mlImages = [
    {
      type: 'image',
      url: 'https://picsum.photos/200/200',
      caption: 'Caption -1'
    },
    {
      type: 'image',
      url: 'https://picsum.photos/id/237/200/200',
      caption: 'Caption -2'
    },
    {
      type: 'image',
      url: 'https://picsum.photos/seed/picsum/200/200',
      caption: 'Caption -3'
    },
    {
      type: 'image',
      url: 'https://picsum.photos/200/200?grayscale',
      caption: 'Caption -4'
    },
    {
      type: 'image',
      url: 'https://picsum.photos/200/200/?blur=2',
      caption: 'Caption -5'
    },
    {
      type: 'image',
      url: 'https://picsum.photos/id/870/200/200?grayscale&blur=2',
      caption: 'Caption -6'
    }
  ];



  public indexs = [];
  currentStep: number;
  constructor(
    private NewreportService: NewreportService,
    public dialog: MatDialog,
    private roboComment: RobocommentService) {

  }

  

  openDialog() {
    if (Object.keys(this.currentFunction).length) {
      const dialogRef = this.dialog.open(PopupSeekDataSource, {
        width: '90%',
        data: { seekDataAbrv: 'HTML.K.L' }
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed', result);
        this.seekDataAbrv = result;
        this.insert();
      });
    } else {
      this.roboComment.setComment({
        status: 'error',
        message: '<b>Please</b>,selecte the position to insert seek data!'
      })
    }
  }

  openMLDialog() {

    const dialogRef = this.dialog.open(PopupMLImage, {
      width: '90%',
      data: { images: this.mlImages, selectedImage: '' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (typeof result !== "undefined") {
        this.insertImage(result);
      }
    });
  }

  async insertSubsection() {


    this.editorComponent.editorInstance.fire('click');

    await this.editorComponent.editorInstance.model.change(writer => {

      const image = writer.createElement('image');
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted subsection!'
      })
    });

    const words = this.content.split('<figure class="image"><img></figure>');
    const last_headings = words[0].split('<h');


    const curent_heading = parseInt(last_headings[last_headings.length - 1].substring(0, 1));

    if (isNaN(curent_heading)) {
      this.editorComponent.editorInstance.setData(words.join(''));
      this.roboComment.setComment({
        status: 'error',
        message: '<b>Invalid Header</b>!'
      });
      return false;
    }

    const pre = curent_heading + '>(.*?)</h' + curent_heading + '>';
    var myRe = new RegExp(pre, 'g');
    var heading_content = myRe.exec(last_headings[last_headings.length - 1]);
    const number = heading_content[1].split(' ');
    const heading_number = number[0] + '.1';

    const next_heading = curent_heading + 1;
    const header = '<h' + next_heading + '>' + heading_number + ' [Heading-' + (next_heading - 1) + ']</h' + next_heading + '>';
    this.editorComponent.editorInstance.setData(words.join(header));
  }

  /**
   * For print 
   */

  printReport() {

    console.log('here', this.currentReport["objective"]);

    /**  to be moved to service 

    const indexs = [
      'executive_summary',
      'introduction',
      'objective',
      'study_design',
      'materials_methods',
      'results',
      'discussion_conclusions',
      'references',
      'annexes',
      'history_of_changes',
      'compile_report'];
      */


      /*
     const indexs = [
      'introduction'];
    let data;
    data = indexs.map(value => this.currentReport[value]);
    data = data.join('');

    console.log('totaldata', data);



    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };


    var pdf = new jsPDF('p', 'pt', 'a4');
    pdf.setFont("Roboto");
    let pdfConf = {
      pagesplit: true, //Adding page breaks manually using pdf.addPage();
      background: '#fff' //White Background.
    };
    pdf.fromHTML(data, 20, 20, {
      width: 500,
      'elementHandlers': specialElementHandlers
    })

    pdf.save("download.pdf");

    */
  }

  /**
   * For print 
   */

  exportReport() {

    console.log('here', this.currentReport["objective"]);

    /**  to be moved to service 

    const indexs = [
      'executive_summary',
      'introduction',
      'objective',
      'study_design',
      'materials_methods',
      'results',
      'discussion_conclusions',
      'references',
      'annexes',
      'history_of_changes',
      'compile_report'];
      */

      /*

     const indexs = [
      'introduction'];
    let data;
    data = indexs.map(value => this.currentReport[value]);
    data = data.join('');

    console.log('totaldata', data);



    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };

    var converted = HtmltoDoc.asBlob(data).saveAs(converted, 'test.docx');
    
    

    var pdf = new jsPDF('p', 'pt', 'a4');
    pdf.setFont("Roboto");
    let pdfConf = {
      pagesplit: true, //Adding page breaks manually using pdf.addPage();
      background: '#fff' //White Background.
    };
    pdf.fromHTML(data, 20, 20, {
      width: 500,
      'elementHandlers': specialElementHandlers
    })

    pdf.save("download.pdf");

    */
  }

  private refreshDisplayMode() {
		const annotations = this.editorComponent.plugins.get( 'Annotations' );
		const sidebarElement = this.sidebarContainer.nativeElement;

		if ( window.innerWidth < 1070 ) {
			sidebarElement.classList.remove( 'narrow' );
			sidebarElement.classList.add( 'hidden' );
			annotations.switchTo( 'inline' );
		}
		else if ( window.innerWidth < 1300 ) {
			sidebarElement.classList.remove( 'hidden' );
			sidebarElement.classList.add( 'narrow' );
			annotations.switchTo( 'narrowSidebar' );
		}
		else {
			sidebarElement.classList.remove( 'hidden', 'narrow' );
			annotations.switchTo( 'wideSidebar' );
		}
  }
  
  private checkPendingActions( domEvt ) {
		if ( this.editorComponent.plugins.get( 'PendingActions' ).hasAny ) {
			domEvt.preventDefault();
			domEvt.returnValue = true;
		}
	}

  ngOnInit(): void {

    this.licenseKey = window.localStorage.getItem( this.STORAGE_KEY ) || window.prompt( 'Your license key' );
    window.localStorage.setItem( this.STORAGE_KEY, this.licenseKey );
    
    

    this.indexs = this.NewreportService.tabindexes;

    this.subscription = this.NewreportService.currentStepChange
      .subscribe(step => {
        console.log('step s', step);
        this.currentStep = step;
        this.content = this.currentReport[this.indexs[this.currentStep]];
        this.showButton = true;
        if (this.currentReport.report_status[this.indexs[this.currentStep]]) {
          this.showButton = false;
        }
        this.isEditorDisabled = false;

        if (this.currentStep == 5) {
          this.getTableOFContent();
        }
      });

  }

  public ngAfterViewInit() {
		if ( !this.sidebarContainer ) {
			throw new Error( 'Div container for sidebar was not found' );
		}

		this.sidebarContainer.nativeElement.appendChild( this.sidebar );
  }
  public ngOnDestroy() {
		window.removeEventListener( 'resize', this.boundRefreshDisplayMode );
		window.removeEventListener( 'beforeunload', this.boundCheckPendingActions );
	}

	public onReady( editor: CKEditor5.Editor ) {
		this.editorComponent = editor;
		this.ready.emit( editor );

		// Make the track changes mode the "default" state by turning it on right after the editor initializes.
		this.editorComponent.execute( 'trackChanges' );

		// Prevent closing the tab when any action is pending.
		window.addEventListener( 'beforeunload', this.boundCheckPendingActions );

		// Switch between inline and sidebar annotations according to the window size.
		window.addEventListener( 'resize', this.boundRefreshDisplayMode );
		this.refreshDisplayMode();
	}


  getTableOFContent() {


    /**
     * If the current step is 7 that is cover page 
    */

    /**  to be moved to service */

    const indexs = [
      'executive_summary',
      'introduction',
      'objective',
      'study_design',
      'materials_methods',
      'results',
      'discussion_conclusions',
      'references',
      'annexes',
      'history_of_changes',
      'compile_report'];
    let data;
    data = indexs.map(value => this.currentReport[value]);
    data = data.join('');

    console.log('totaldata', data);


    let headers_htmls = [];
    headers_htmls = indexs.map(index => {

      //console.log('content',  this.currentReport[index]);
      //console.log('index',index)

      const total_headers = this.currentReport[index].split('<h');

      let headers_html = "";
      let currentList = 0;
      let tableJson = {};
      let number_ul = 0;
      let headers = total_headers.map(data => {
        // console.log(data);
        if (data.trim()) {
          const number = parseInt(data.substring(0, 1));
          const pre = number + '>(.*?)</h' + number + '>';
          var myRe = new RegExp(pre, 'g');
          var myArray = myRe.exec(data);

          if (myArray && myArray[1]) {

            const li = "<li>" + myArray[1] + "</li>";
            // console.log('number' + number + 'currentList' + currentList);

            if (currentList < number) {
              headers_html += '<ul>' + li;
              number_ul++;
            }
            if (currentList > number) {

              headers_html += '</ul>' + li;
            }
            if (number == currentList) {
              headers_html += li;
            }
            currentList = number;
          }
        }
      });

      if (headers_html != '') {
        for (let i = 0; i < number_ul; i++) {
          headers_html += "</ul>";
        }
      }
      return headers_html;
    });

    //

    let image_html = [];
    image_html = indexs.map(index => {
      const pre = '<figcaption>(.*?)</figcaption>';
      let captions = [...this.currentReport[index].matchAll(pre)];
      if (captions.length > 0) {
        let data = captions.map(data => "<li>" + data[1] + "</li>");
        return data.join('');
      } else {
        return [];
      }
    });

    const n = "<h2>Table of Content</h2>" + headers_htmls.join('') + "<h3>Table of Figures and Tables</h3><ul>" + image_html.join('') + '</ul>';
    this.content = n;
    this.isEditorDisabled = true;
  }

  save() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Saved</b> this section Successfully!'
    })
    this.currentReport[this.indexs[this.currentStep]] = this.content;

    this.currentReport.report_status[this.indexs[this.currentStep]] = 0;
  }

  commit() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Committed</b> this section Successfully!'
    })
    this.currentReport.report_status[this.indexs[this.currentStep]] = 1;
    this.showButton = false;
  }

  insert() {
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      writer.insertText(this.seekDataAbrv, this.currentPosition);
      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  insertImage(image) {
    const src = image.url;
    const last_headings = this.content.split('<figure'); // + (this.currentStep - 4) + '.'
    const captionText = 'Fig-' + last_headings.length + ':' + image.caption;
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      const image = writer.createElement('image', { src: src });
      const caption = writer.createElement('caption');
      writer.appendText(captionText, caption);
      writer.append(caption, image);
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  getPosition() {

    this.currentPosition = this.editorComponent.editorInstance.model.document.selection.getFirstPosition();
    this.editorComponent.editorInstance.model.change(writer => {
      this.currentFunction = writer;
    });
  }
}



@Component({
  selector: 'popoup-seek-data-source',
  templateUrl: 'popoup-seek-data-source.html',
  styleUrls: ['../seek-data-source/seek-data-source.component.sass']
})
export class PopupSeekDataSource {

  pims_ids: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];

  currentReport: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];
  today = new Date();


  constructor(
    public dialogRef: MatDialogRef<PopupSeekDataSource>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }


  loadData(id = 1) {
    let temp = this.pims_ids[0];
    Object.keys(temp).forEach((value, index) => {
      // this.currentReport[value] = temp[value];
    });
  }

  closePopUp() {
    this.dialogRef.close();
  }

  seek() {

  }

}




@Component({
  selector: 'popoup-mlimages',
  templateUrl: 'popoup-ml-images.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class PopupMLImage {
  selected

  constructor(
    public dialogRef: MatDialogRef<PopupMLImage>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    data.selectedImage = data.images[0];
    // console.log(data.images)
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  closeMlPopup() {
    this.dialogRef.close();
  }

  insertMlImage() {
    console.log('data.selectedImage', this.data.selectedImage);
    this.dialogRef.close();
  }

}
