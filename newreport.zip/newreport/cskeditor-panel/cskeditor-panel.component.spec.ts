import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CskeditorPanelComponent } from './cskeditor-panel.component';

describe('CskeditorPanelComponent', () => {
  let component: CskeditorPanelComponent;
  let fixture: ComponentFixture<CskeditorPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CskeditorPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CskeditorPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
