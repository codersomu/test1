import { Component, OnInit, ViewChild, Input, Inject } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NewreportService } from "../../_services/newreport.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RobocommentService } from "../../_services/robocomment.service";
import { Subscription } from 'rxjs';



@Component({
  selector: 'app-cskeditor-panel',
  templateUrl: './cskeditor-panel.component.html',
  // templateUrl: './popoup-seek-data-source.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class CskeditorPanelComponent implements OnInit {

  public Editor = ClassicEditor;
  public selection = 0;
  public currentPosition: any = 0;
  public currentFunction: any = {};
  public content: any = '';
  public orginalContent: any = '';
  public showButton: boolean = true;
  public isEditorDisabled = false;

  private subscription: Subscription;

  public seekDataAbrv = "";

  /*
 `data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAAUA
    AAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO
        9TXL0Y4OHwAAAABJRU5ErkJggg==`
  */
  public mlImages = [
    'https://picsum.photos/200/200',
    'https://picsum.photos/id/237/200/200',
    'https://picsum.photos/seed/picsum/200/200',
    'https://picsum.photos/200/200?grayscale',
    'https://picsum.photos/200/200/?blur=2',
    'https://picsum.photos/id/870/200/200?grayscale&blur=2'
  ];



  public indexs = [];
  currentStep: number;
  constructor(
    private NewreportService: NewreportService,
    public dialog: MatDialog,
    private roboComment: RobocommentService) {

  }

  @ViewChild('editor') editorComponent: ClassicEditor;
  @Input() currentReport: any;

  checkValid(data) {
    return true;
    console.log('chnaged');
    const words = data.split('--explode--');
    console.log('data', words);
    // words.map(data=>this.content = data.replace(/--explode--/g, ''));
    /*

    data.replace(/--explode--/g, function (match,  offset, contents, input_string) {
        console.log('contents',contents );
        // this.content = contents.replace(/ /g, '');
        return contents.replace(/--explode--/g, '');
      }
    );
    console.log('replaced data',  data)

    */
    return data.replace(/--explode--/g, '');
    //console.log(' this.orginalContent', this.orginalContent);
    //this.content = this.orginalContent;

    // setTimeout(function(){ this.content = data }, 1000);
    // this.content = data.replace(/--explode--/g, '');
  }


  openDialog() {

    if (Object.keys(this.currentFunction).length) {
      const dialogRef = this.dialog.open(PopupSeekDataSource, {
        width: '90%',
        data: { seekDataAbrv: 'HTML.K.L' }
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed', result);
        this.seekDataAbrv = result;
        this.insert();
      });
    } else {
      this.roboComment.setComment({
        status: 'error',
        message: '<b>Please</b>,selecte the position to insert seek data!'
      })
    }
  }

  openMLDialog() {

    const dialogRef = this.dialog.open(PopupMLImage, {
      width: '90%',
      data: { images: this.mlImages, selectedImage: '' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (typeof result !== "undefined") {
        this.insertImage(result);
      }
    });
  }

  async insertSubsection() {


    this.editorComponent.editorInstance.fire('click');

    await this.editorComponent.editorInstance.model.change(writer => {

      const image = writer.createElement('image');
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });




    const words = this.content.split('<figure class="image"><img></figure>');
    const last_headings = words[0].split('<h');
    const next_heading = parseInt(last_headings[last_headings.length - 1].substring(0, 1)) + 1;
    // const header = '<h'+ next_heading + '>[Sub-section]</h'+  next_heading + '>';
    const header = '<h' + next_heading + '>[Heading-' + (next_heading - 1) + ']</h' + next_heading + '>';

    this.editorComponent.editorInstance.setData(words.join(header));

    // var matches = this.editorComponent.editorInstance.getData.match(/<h1>(\d+)\][(\d+)\]/);

    // this.content = await this.content.replace('<figure class="image"><img></figure>', '');


    //this.editorComponent.editorInstance.model.insertContent( writer.createElement( 'header1' ), this.currentPosition);

    /*

    this.editorComponent.editorInstance.model.change( writer => {
      console.log('ssss');
      this.editorComponent.editorInstance.model.insertContent( 'header2', this.currentPosition);
    });
    */




    /*

    const docFrag = this.editorComponent.editorInstance.model.change( writer => {
      const header = writer.createElement( 'header1' );
      const docFrag = writer.createDocumentFragment();  
      writer.insert( '--explode--', docFrag);

      this.editorComponent.editorInstance.model.insertContent( writer.createElement( 'header1' ), this.currentPosition);
      // writer.insertText( 'Subsection', header );  
      return docFrag;
  } );

  this.editorComponent.editorInstance.model.insertContent( docFrag );

  */



    /*
    
    this.editorComponent.editorInstance.model.change( writer => {

      // writer.insertText( '--explode--', this.currentPosition); 

      console.log('Please',writer.createDocumentFragment());

      //console.log('your_editor.getItems()', writer.model)

      //const range = writer.createRange( start, end );
      //const selection = new DocumentSelection( range );

      //console.log('your_editor.getSelection()', writer.model.getSelectedContent(0,1))
     // console.log('currentPosition', this.currentPosition.root.document.model.getSelectedContent());

      //const Text = this.content.slice(0,this.currentPosition.path[1]);
      //console.log('Text', Text);
      //console.log( this.currentPosition.path);

      
      
      const heading1 = writer.createElement( 'heading1' );

      // const text = writer.createText( 'Arvind somu' );

      // writer.insertText( 'foo', writer.createElement( 'heading1' ), 'end' );

      // writer.insert( text, heading1, 'end' );
      // writer.insert('Example',heading1, 'end' );
      //writer.insert( text, heading1, 0 );
      // writer.insert( this.currentPosition, writer.createText( 'foo' ) );

     

      this.roboComment.setComment({
        status : 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });

    */
  }




  ngOnInit(): void {
    this.indexs = this.NewreportService.tabindexes;

    this.subscription = this.NewreportService.currentStepChange
      .subscribe(step => {
        console.log('step',step);
        this.currentStep = step;
        this.content = this.currentReport[this.indexs[this.currentStep]];
        this.showButton = true;
        if (this.currentReport.report_status[this.indexs[this.currentStep]]) {
          this.showButton = false;
        }
        this.isEditorDisabled = false;

        if(this.currentStep == 5 ) { 
          this.getTableOFContent();
        }
      });   

  }

  getTableOFContent(){
    

    /**
     * If the current step is 7 that is cover page 
    */

   console.log('this.currentStep', this.currentStep);

     /**  to be moved to service */

     const indexs = ['executive_summary',
       'introduction',
       'objective',
       'study_design',
       'materials_methods',
       'results',
       'discussion_conclusions',
       'references',
       'annexes',
       'history_of_changes',
       'compile_report'];

     let content ='';
     content += indexs.map(index => {
       console.log('index',index)
       return this.currentReport[index]
     });


     console.log('content', content);
     const total_headers = content.split('<h');
     let html = "";
     let currentList = 0;
     let headers = total_headers.map(data => {
       if (data.trim()) {
         const number = parseInt(data.substring(0, 1));
         const pre = number + '>(.*?)</h' + number + '>';
         var myRe = new RegExp(pre, 'g');
         var myArray = myRe.exec(data);
         if (myArray[1]) {
           const li = "<li>" + myArray[1] + "</li>";
           console.log('number' + number + 'currentList' + currentList);

           if (currentList < number) {
             html += '<ul>' + li;
           }
           if (currentList > number) {

             html += '</ul>' + li;
           }
           if (number == currentList) {
             html += li;
           }
           currentList = number;
         }
       }
     });

     html += "</ul>";

     this.content = html;
     this.isEditorDisabled = true;
  }

  save() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Saved</b> this section Successfully!'
    })
    this.currentReport[this.indexs[this.currentStep]] = this.content;

    this.currentReport.report_status[this.indexs[this.currentStep]] = 0;
  }

  commit() {
    this.roboComment.setComment({
      status: 'success',
      message: 'You have <b>Committed</b> this section Successfully!'
    })
    this.currentReport.report_status[this.indexs[this.currentStep]] = 1;
    this.showButton = false;
  }

  insert() {
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      writer.insertText(this.seekDataAbrv, this.currentPosition);
      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  insertImage(image) {
    const src = image;
    this.editorComponent.editorInstance.fire('click');
    this.editorComponent.editorInstance.model.change(writer => {
      const image = writer.createElement('image', { src: src });
      const caption = writer.createElement('caption');
      writer.appendText('Fig-xx', caption);
      writer.append(caption, image);
      this.editorComponent.editorInstance.model.insertContent(image, this.currentPosition);

      writer.setSelection(image, 'on');

      this.roboComment.setComment({
        status: 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });
  }

  getPosition() {

    const t = this.content
    this.orginalContent = t;

    //  console.log('arvind', this.editorComponent.editorInstance.model.getSelectedContent( this.editorComponent.editorInstance.model, this.editorComponent.editorInstance.model.document.selection.getFirstPosition() ));
    this.currentPosition = this.editorComponent.editorInstance.model.document.selection.getFirstPosition();
    this.editorComponent.editorInstance.model.change(writer => {
      /**
       * For getting current position text to parent 
      
      (async () => {
          await 
          const words = await this.content.split('--explode--');        
          await console.log('data',words);
          // this.content = await words.join();this.content.replace(/--explode--/g, '');
      })();  */
      // writer.insertText( '--explode--', this.currentPosition);      
      this.currentFunction = writer;
    });

    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');


    // this.content = t;
    /*
    this.editorComponent.editorInstance.model.change( writer => {
        console.log('chnaged',this.content);
        this.content = this.content.replace(/--explode--/g, '');
    });
    */
    // this.content = 's';//this.checkValid(this.content);
  }
}



@Component({
  selector: 'popoup-seek-data-source',
  templateUrl: 'popoup-seek-data-source.html',
  styleUrls: ['../seek-data-source/seek-data-source.component.sass']
})
export class PopupSeekDataSource {

  pims_ids: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];

  currentReport: any = [{
    pims_id: '2201545',
    version_id: '1.01',
    project_name: 'RSV-Pa>>',
    study_type: 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];
  today = new Date();


  constructor(
    public dialogRef: MatDialogRef<PopupSeekDataSource>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }


  loadData(id = 1) {
    let temp = this.pims_ids[0];
    Object.keys(temp).forEach((value, index) => {
      // this.currentReport[value] = temp[value];
    });
  }

  closePopUp() {
    this.dialogRef.close();
  }

  seek() {

  }

}




@Component({
  selector: 'popoup-mlimages',
  templateUrl: 'popoup-ml-images.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class PopupMLImage {
  selected

  constructor(
    public dialogRef: MatDialogRef<PopupMLImage>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    data.selectedImage = data.images[0];
    // console.log(data.images)
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  closeMlPopup() {
    this.dialogRef.close();
  }

  insertMlImage() {
    console.log('data.selectedImage', this.data.selectedImage);
    this.dialogRef.close();
  }

}
