import { Component, OnInit,ViewChild, Input, Inject } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic'; 
import {NewreportService} from "../../_services/newreport.service";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {RobocommentService} from "../../_services/robocomment.service";
import { Subscription } from 'rxjs';



@Component({
  selector: 'app-cskeditor-panel',
  templateUrl: './cskeditor-panel.component.html',
  // templateUrl: './popoup-seek-data-source.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class CskeditorPanelComponent implements OnInit {

  public Editor = ClassicEditor;
  public selection = 0;
  public currentPosition : any= 0;
  public currentFunction: any = {};
  public content: any = '';
  public orginalContent: any = '';
  public showButton : boolean = true;

  private subscription: Subscription;

  public seekDataAbrv = "";

  /*
 `data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAAUA
    AAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO
        9TXL0Y4OHwAAAABJRU5ErkJggg==`
  */
  public mlImages = [
    'https://picsum.photos/200/200',
    'https://picsum.photos/id/237/200/200',
    'https://picsum.photos/seed/picsum/200/200',
    'https://picsum.photos/200/200?grayscale',
    'https://picsum.photos/200/200/?blur=2',
    'https://picsum.photos/id/870/200/200?grayscale&blur=2'
  ];



  public indexs = [];
  currentStep : number;
  constructor(
    private NewreportService : NewreportService,
    public dialog: MatDialog,
    private roboComment : RobocommentService) {
     
  }

  @ViewChild( 'editor' ) editorComponent: ClassicEditor;
  @Input() currentReport: any;

  checkValid(data){
    return true;
    console.log('chnaged');
    const words = data.split('--explode--');        
    console.log('data',words);
    // words.map(data=>this.content = data.replace(/--explode--/g, ''));
    /*

    data.replace(/--explode--/g, function (match,  offset, contents, input_string) {
        console.log('contents',contents );
        // this.content = contents.replace(/ /g, '');
        return contents.replace(/--explode--/g, '');
      }
    );
    console.log('replaced data',  data)

    */
   return data.replace(/--explode--/g, '');
   //console.log(' this.orginalContent', this.orginalContent);
    //this.content = this.orginalContent;
      
   // setTimeout(function(){ this.content = data }, 1000);
    // this.content = data.replace(/--explode--/g, '');
  }


  openDialog(){

    if( Object.keys( this.currentFunction).length ){
      const dialogRef = this.dialog.open(PopupSeekDataSource, {
        width: '90%',
        data  : {seekDataAbrv: 'HTML.K.L'}
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed',result);
        this.seekDataAbrv = result;
        this.insert();
      });
    }else{
      this.roboComment.setComment({
        status : 'error',
        message: '<b>Please</b>,selecte the position to insert seek data!'
      })
    }
  }

  openMLDialog(){

      const dialogRef = this.dialog.open(PopupMLImage, {
        width: '90%',
        data  : { images: this.mlImages, selectedImage: ''}
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed',result);
        if(typeof result !== "undefined"){
          this.insertImage(result);
        }
      });
  }

  insertSubsection(){                                                                                                                                                
    

    this.editorComponent.editorInstance.fire( 'click' );

    const docFrag = this.editorComponent.editorInstance.model.change( writer => {
      const header = writer.createElement( 'header1' );
      const docFrag = writer.createDocumentFragment();  
      writer.insert( '--explode--', docFrag);

      this.editorComponent.editorInstance.model.insertContent( writer.createElement( 'header1' ), this.currentPosition);
      // writer.insertText( 'Subsection', header );  
      return docFrag;
  } );

  this.editorComponent.editorInstance.model.insertContent( docFrag );



    /*
    
    this.editorComponent.editorInstance.model.change( writer => {

      // writer.insertText( '--explode--', this.currentPosition); 

      console.log('Please',writer.createDocumentFragment());

      //console.log('your_editor.getItems()', writer.model)

      //const range = writer.createRange( start, end );
      //const selection = new DocumentSelection( range );

      //console.log('your_editor.getSelection()', writer.model.getSelectedContent(0,1))
     // console.log('currentPosition', this.currentPosition.root.document.model.getSelectedContent());

      //const Text = this.content.slice(0,this.currentPosition.path[1]);
      //console.log('Text', Text);
      //console.log( this.currentPosition.path);

      
      
      const heading1 = writer.createElement( 'heading1' );

      // const text = writer.createText( 'Arvind somu' );

      // writer.insertText( 'foo', writer.createElement( 'heading1' ), 'end' );

      // writer.insert( text, heading1, 'end' );
      // writer.insert('Example',heading1, 'end' );
      //writer.insert( text, heading1, 0 );
      // writer.insert( this.currentPosition, writer.createText( 'foo' ) );

     

      this.roboComment.setComment({
        status : 'success',
        message: '<b>Successfully</b> inserted seek data!'
      })
    });

    */


    const words = this.content.split('--explode--');        
      console.log('data',words);      
    this.content = this.content.replace(/--explode--/g, '');


    this.editorComponent.editorInstance.model.change( writer => {
      writer.insertElement( writer.createElement( 'heading2' ),  writer.createDocumentFragment());
    });
    
  }




  ngOnInit(): void {
      this.indexs  = this.NewreportService.tabindexes;
      
      this.subscription = this.NewreportService.currentStepChange
      .subscribe(step => {
        this.currentStep= step;
        this.content = this.currentReport[this.indexs[this.currentStep]];
        this.showButton = true;
        if(this.currentReport.report_status[this.indexs[this.currentStep]]){
          this.showButton = false;
        }
      });

  }

  save(){
    this.roboComment.setComment({
      status : 'success',
      message: 'You have <b>Saved</b> this section Successfully!'
    })

    this.currentReport.report_status[this.indexs[this.currentStep]] = 0;
  }

  commit(){
    this.roboComment.setComment({
      status : 'success',
      message: 'You have <b>Committed</b> this section Successfully!'
    })
    this.currentReport.report_status[this.indexs[this.currentStep]] = 1;
    this.showButton = false;
  }

  insert(){
    this.editorComponent.editorInstance.fire( 'click' );
    this.editorComponent.editorInstance.model.change( writer => {
        writer.insertText( this.seekDataAbrv, this.currentPosition);
        this.roboComment.setComment({
          status : 'success',
          message: '<b>Successfully</b> inserted seek data!'
        })
    });
  }

  insertImage(image){   
    const src = image;
    this.editorComponent.editorInstance.fire( 'click' );
    this.editorComponent.editorInstance.model.change( writer => {
      const image = writer.createElement( 'image', { src: src} );
      const caption = writer.createElement( 'caption' );
      writer.appendText( 'Fig-xx', caption );
      writer.append( caption, image );
      this.editorComponent.editorInstance.model.insertContent( image, this.currentPosition);

      writer.setSelection( image, 'on' );

        this.roboComment.setComment({
          status : 'success',
          message: '<b>Successfully</b> inserted seek data!'
        })
    });
  }

  getPosition(){
    
    const t =  this.content
    this.orginalContent = t;
   
   //  console.log('arvind', this.editorComponent.editorInstance.model.getSelectedContent( this.editorComponent.editorInstance.model, this.editorComponent.editorInstance.model.document.selection.getFirstPosition() ));
    this.currentPosition = this.editorComponent.editorInstance.model.document.selection.getFirstPosition();
    this.editorComponent.editorInstance.model.change( writer => {
      /**
       * For getting current position text to parent 
      
      (async () => {
          await 
          const words = await this.content.split('--explode--');        
          await console.log('data',words);
          // this.content = await words.join();this.content.replace(/--explode--/g, '');
      })();  */
      // writer.insertText( '--explode--', this.currentPosition);      
      this.currentFunction = writer;
    });

    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');
    //this.content = this.content.replace(/--explode--/g, '');

    
    // this.content = t;
    /*
    this.editorComponent.editorInstance.model.change( writer => {
        console.log('chnaged',this.content);
        this.content = this.content.replace(/--explode--/g, '');
    });
    */
    // this.content = 's';//this.checkValid(this.content);
  }
}



@Component({
  selector: 'popoup-seek-data-source',
  templateUrl: 'popoup-seek-data-source.html',
  styleUrls: ['../seek-data-source/seek-data-source.component.sass']
})
export class PopupSeekDataSource{

  pims_ids: any = [{
    pims_id : '2201545',
    version_id: '1.01',
    project_name : 'RSV-Pa>>',
    study_type : 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];

  currentReport :  any = [{
    pims_id : '2201545',
    version_id: '1.01',
    project_name : 'RSV-Pa>>',
    study_type : 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];
  today = new Date();


  constructor(
    public dialogRef: MatDialogRef<PopupSeekDataSource>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }


  loadData(id = 1){
    let temp = this.pims_ids[0];
    Object.keys(temp).forEach((value,index) => {
      // this.currentReport[value] = temp[value];
    });
  }

  closePopUp(){
    this.dialogRef.close();
  }

  seek(){

  }

}




@Component({
  selector: 'popoup-mlimages',
  templateUrl: 'popoup-ml-images.html',
  styleUrls: ['./cskeditor-panel.component.sass']
})
export class PopupMLImage {
  selected

  constructor(
    public dialogRef: MatDialogRef<PopupMLImage>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      data.selectedImage = data.images[0];
      // console.log(data.images)
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  closeMlPopup(){
    this.dialogRef.close();
  }

  insertMlImage(){
    console.log('data.selectedImage', this.data.selectedImage);
    this.dialogRef.close();
  }

}
