import { Component, OnInit, Output, EventEmitter,Input } from '@angular/core';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.sass']
})
export class UploadDocumentsComponent implements OnInit {
  files: File[] = [];
  @Output() showPageEvent = new EventEmitter<string>();

  @Input() currentReport: any;


  constructor() { 
    
  }

  ngOnInit(): void {
    this.files = this.currentReport.uploaded_docs
  }
  onSelect(event) {
    //console.log( this.currentReport);console.log(this.files);
    this.files.push(...event.addedFiles);
    //this.currentReport.uploaded_docs.push(...event.addedFiles);
    //console.log( this.currentReport);console.log(this.files);
  }
   
  onRemove(event) {
    console.log(event);
    this.files.splice(this.files.indexOf(event), 1);
  } 

  save(){
    this.showPageEvent.emit('8')
  }
}
