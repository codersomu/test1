let input = {
    /**
     * Assign Team Members
     */
    co_author: [{
        // group_id: 'Vaccine (In-Vivo)',
        // employee_ids: ["Kiran Ghanta (TTT)","Hélène Goossens"]
        group_id: '',
        employee_ids: []
    }, {
        group_id: '',
        employee_ids: []
    }],
    reviewers: [{
        group_id: '',
        employee_ids: []
    }],
    approvers: [{
        group_id: '',
        employee_ids: []
    }],

    /**
     * Seek Data Source 
     */

    pims_id: '',
    version_id: '',
    start_date: new Date(),
    end_date: '',
    project_name: '',
    study_type: '',
    ethical_protocol_number: '',
    readouts: '',
    animal_species: '',
    immunization_route: '',
    challenge_route: '',
    pathogen: '',
    antigen: '',
    adjuvant: '',
    any_other_keywords: '',

    /**
     * Upload Documents
     */

    uploaded_docs: [],

    sections: {
        cover_page: {
            section: "a",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        table_of_content: {
            section: "b",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        executive_summary: {
            section: "1",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        introduction: {
            section: "2",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        objective: {
            section: "2.2",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        study_design: {
            section: "2.3",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        materials_methods: {
            section: "3",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        results: {
            section: "4",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        discussion_conclusions: {
            section: "5",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        references: {
            section: "6",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        annexes: {
            section: "7",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        history_of_changes: {
            section: "8",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        },

        compile_report: {
            section: "8",
            modified: [
                {
                    "name": "",
                    "modifiedon": ""
                },
                {
                    "name": "",
                    "modifiedon": ""
                }
            ],
            locked_by: 0,
            is_locked: 0,
            is_committed: 0,
            content: ``
        }
    }
}

export default input;