import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import {NewreportService} from "../../_services/newreport.service";

@Component({
  selector: 'app-report-description',
  templateUrl: './report-description.component.html',
  styleUrls: ['./report-description.component.sass']
})
export class ReportDescriptionComponent implements OnInit {
  currentReport;
  co_author;
  reviewers;
  approvers;

  @Output() showPageEvent = new EventEmitter<string>();

  constructor(private NewreportService : NewreportService) { }

  ngOnInit(): void {
    this.currentReport = this.NewreportService.currentReport;

    this.co_author  = this.currentReport.co_author.map(data => {
      return data.employee_ids;
    });

    this.reviewers  = this.currentReport.reviewers.map(data => {
      return data.employee_ids;
    });

    this.approvers  = this.currentReport.co_author.map(data => {
      return data.employee_ids;
    });

  }

  edit(){
    this.showPageEvent.emit('1')
  }
  editSeekData(){
    this.showPageEvent.emit('2')
  }
}
