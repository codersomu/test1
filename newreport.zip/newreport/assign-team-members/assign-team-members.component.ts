import { Component, OnInit, Output, EventEmitter,ElementRef, ViewChild,Input } from '@angular/core';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {FormControl} from '@angular/forms';
import {MatAutocompleteSelectedEvent, MatAutocomplete} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {RobocommentService} from "../../_services/robocomment.service";
 

interface Groups {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-assign-team-members',
  templateUrl: './assign-team-members.component.html',
  styleUrls: ['./assign-team-members.component.sass']
})
export class AssignTeamMembersComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl();
  filteredEmployes: Observable<string[]>;
  fruits: string[] = [];
  allEmployes: string[] = ['Kiran Ghanta (TTT)', 'Hélène Goossens', 'Prabha Mishra', 'Mario Chenier Edwards', 'Mathew Chacko',
'Ludmila Tydlitatova','Tanguy Naets','Nadia Ouaked','Samyabrata Chakrabarty','Sourav Bhattacharyya','Paul Smyth','Sander Timmer',
 'Stéphane Temmerman'];

  groups: Groups[] = [
    {value: 'Vaccine (In-Vivo)', viewValue: 'Vaccine (In-Vivo)'},
    {value: 'Vaccine (In-Vitro)', viewValue: 'Vaccine (In-Vitro)'},
    {value: 'Statstics', viewValue: 'Statstics'}
  ];

  @Output() showPageEvent = new EventEmitter<string>();

  @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  @Input() currentReport: any;



  constructor(private roboComment : RobocommentService) {
      this.filteredEmployes = this.fruitCtrl.valueChanges.pipe(
      startWith(null),
      map((fruit: string | null) => fruit ? this._filter(fruit) : this.allEmployes.slice()));

      
   }

  ngOnInit(): void {
    this.roboComment.setComment({
      status : 'success',
      message: '<b>Welcome!</b>'
    })
  }

  save(){
    this.roboComment.setComment({});
    this.showPageEvent.emit('2')
  }

  reset(){
    this.currentReport.co_author = [{
      group_id: '',
      employee_ids: []
    }];
    this.currentReport.reviewers = [{
      group_id: '',
      employee_ids: []
  }];
    this.currentReport.approvers = [{
      group_id: '',
      employee_ids: []
  }];
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.fruits.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.fruitCtrl.setValue(null);
  }

  remove(employee_id: string , section = []): void {
    const index = section.indexOf(employee_id);

    if (index >= 0) {
      section.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent, employee_ids = []): void {
    employee_ids.push(event.option.viewValue);
    this.fruitInput.nativeElement.value = '';
    this.fruitCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.allEmployes.filter(employe => employe.toLowerCase().indexOf(filterValue) === 0);
  }

  addMore(section){
    section.push({
      group_id: '',
      employee_ids: []
    })
  }

  deleteSection(input, section){
    section.splice(input, 1);
  }

}
