import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeekDataSourceComponent } from './seek-data-source.component';

describe('SeekDataSourceComponent', () => {
  let component: SeekDataSourceComponent;
  let fixture: ComponentFixture<SeekDataSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeekDataSourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeekDataSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
