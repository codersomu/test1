import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-seek-data-source',
  templateUrl: './seek-data-source.component.html',
  styleUrls: ['./seek-data-source.component.sass']
})
export class SeekDataSourceComponent implements OnInit {

  selectedValue = '';
  fruits: string[] = [];
  today : Date;

  pims_ids: any = [{
    pims_id : '2201545',
    version_id: '1.01',
    project_name : 'RSV-Pa>>',
    study_type : 'Efficacy / Challenge',
    ethical_protocol_number: 'POO5/32/01',
    readouts: 'Reciprocal of Highest Dilution',
    animal_species: 'MOU, 014, F',
    immunization_route: 'INAS',
    challenge_route: 'SCUT',
    pathogen: 'Challenge Avec B. Pertussis',
    antigen: 'Antigen (PA-Sur AIOHa 100ug/ml)',
    adjuvant: '',
    any_other_keywords: ''
  }];

  @Output() showPageEvent = new EventEmitter<string>();
  @Input() currentReport: any;

  constructor() { }

  ngOnInit(): void {
    this.today = new Date();

    console.log(this.currentReport);
  }

  save(){
    this.showPageEvent.emit('3')
  }
  loadData(id = 1){
    let temp = this.pims_ids[0];
    Object.keys(temp).forEach((value,index) => {
      this.currentReport[value] = temp[value];
    });
  }

}
