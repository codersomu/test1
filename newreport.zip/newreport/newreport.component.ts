import { Component, OnInit, ViewChild } from '@angular/core';
import inputJson from './create_report';
import { NewreportService } from "../_services/newreport.service";
import { CskeditorPanelComponent } from './cskeditor-panel/cskeditor-panel.component';


@Component({
  selector: 'app-newreport',
  templateUrl: './newreport.component.html',
  styleUrls: ['./newreport.component.sass']
})
export class NewreportComponent implements OnInit {
  currentStep = 5;  // 1
  currentReport = inputJson

  @ViewChild(CskeditorPanelComponent) cskEditor: CskeditorPanelComponent;

  constructor(private NewreportService: NewreportService) { }

  ngOnInit(): void {
    this.NewreportService.setCurrentReport(this.currentReport);
  }

  showStep(step) {

    console.log('step here', step);
    if (step == 5) {
      this.currentStep = step;
      this.NewreportService.setCurrentStep(step);
    }
    else if (this.isEditable(step)) {
      this.currentStep = step;
      this.NewreportService.setCurrentStep(step)
    }
    // this.currentStepChange.next(true);
  }


  isEditable(step) {
    return this.NewreportService.isEditable(step)
  }

  getClasses(step) {
    let classes = '';
    if (this.currentStep == step) {
      classes += 'current-menu ';
    }

    if (this.currentReport.report_status[this.NewreportService.tabindexes[step]]) {
      classes += ' menu-is-commited'
    }

    if (this.isEditable(step)) {
      classes += ' menu-is-editable'
    }
    return classes;
  }

  openSeekDataSource() {
    this.cskEditor.openDialog();
  }

  insertSubsection() {
    this.cskEditor.insertSubsection();
  }

  printReport() {
    this.cskEditor.printReport();
  }
  exportReport(){
    this.cskEditor.exportReport();
  }



}
